package com.design.urlshortener;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyUrlShortenerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyUrlShortenerApplication.class, args);
	}

}

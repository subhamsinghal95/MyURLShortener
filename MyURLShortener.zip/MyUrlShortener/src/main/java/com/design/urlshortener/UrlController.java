package com.design.urlshortener;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.Cacheable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class UrlController {
	
private Map<String, UrlModel> shortenUrlList = new HashMap<>();
	private BaseConversion conversion;
	private final UrlService urlService;
	
    public UrlController(UrlService urlService) {
        this.urlService = urlService;
    }
    
    @PostMapping("shortenurl")
    public String convertToShortUrl(@RequestBody UrlModel request) {
        return urlService.convertToShortUrl(request);
    } 
    
    @GetMapping(value = "{shortUrl}")
    public ResponseEntity<Void> getAndRedirect(@PathVariable String shortUrl) {
        String url = urlService.getOriginalUrl(shortUrl);
        return ResponseEntity.status(HttpStatus.FOUND)
                .location(URI.create(url))
                .build();
    }
}
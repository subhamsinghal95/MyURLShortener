package com.design.urlshortener;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyUrlShortenerApplicationTests {

	@Test
	void contextLoads() {
	}

}
